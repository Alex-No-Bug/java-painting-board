package paintBoard;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class DrawStringWindow extends JFrame  implements  FocusListener{  
	    private JLabel jl1;
	    private JTextField jtf1;
	    private JButton jb;
	    private JPanel jp2;
	    private MyPanel mp;
		private String s;
		
	    public DrawStringWindow()
	    {
	    	//输入文本
	    	jl1=new JLabel("Please input the string:");
			jtf1 = new JTextField(6);
			jtf1.addFocusListener(this);
            //确定的按钮
			jb = new JButton("Confirm");
            jb.setBackground(Color.GRAY);
			jb.addActionListener(new ActionListener( )
			{
				public void actionPerformed(ActionEvent e)
				{
				if(e.getSource()==jb)
				{
					s=jtf1.getText();
					
				}	
				}
			});
		mp = new MyPanel();
        jp2 = new JPanel();
        jp2.add(jl1);
        jp2.add(jtf1);
        jp2.add(jb);
		this.add(mp);
        this.add(jp2, BorderLayout.NORTH);
        this.setSize(400, 400);
        this.setVisible(true);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	    }
		
	 public void focusGained(FocusEvent e) {
        if (e.getSource() == jtf1) {
            jtf1.setText("");
        }
    }
 
    public void focusLost(FocusEvent e) {
    }
	//和外部函数相连接
		public String getString()
		{
			return(s);
		}
}
