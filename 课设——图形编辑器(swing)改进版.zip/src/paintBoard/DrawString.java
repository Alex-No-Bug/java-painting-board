package paintBoard;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class DrawString extends JFrame  implements  FocusListener{  
	    private JLabel jl1,jl2,jl3;
	    private JTextField jtf1,jtf2,jtf3;
	    private JButton jb;
	    private JPanel jp2;
	    private MyPanel mp;
		private String s;
		private int x,y;
	    public DrawString()
	    {
	    	//输入文本
	    	jl1=new JLabel("Please input the string:");
			jtf1 = new JTextField(6);
			jtf1.addFocusListener(this);
             //输入x
			jl2=new JLabel("Please input the locationX:");
			jtf2 = new JTextField(3);
			jtf2.addFocusListener(this);
            //输入Y
			jl2=new JLabel("Please input the locationX:");
			jtf2 = new JTextField(3);
			jtf2.addFocusListener(this);
            //确定的按钮
			jb = new JButton("Confirm");
            jb.setBackground(Color.GRAY);
			jb.addActionListener(new ActionListener( )
			{
				public void actionPerformed(ActionEvent e)
				{
				if(e.getSource()==jb)
				{
					s=jtf1.getText();
					x=Integer.parseInt(jtf2.getText());
					y=Integer.parseInt(jtf3.getText());
				}	
				}
			});
		mp = new MyPanel();
        jp2 = new JPanel();
        jp2.add(jl1);
        jp2.add(jtf1);
		jp2.add(jl2);
        jp2.add(jtf2);
		jp2.add(jl3);
		jp2.add(jtf3);
        jp2.add(jb);
		this.add(mp);
        this.add(jp2, BorderLayout.NORTH);
        this.setSize(500, 500);
        this.setVisible(true);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	    }
		
	 public void focusGained(FocusEvent e) {
        if (e.getSource() == jtf1) {
            jtf1.setText("");
        }
		else if (e.getSource() == jtf2) {
            jtf2.setText("");
        }
		else if (e.getSource() == jtf3) {
            jtf3.setText("");
        }
    }
  
    public void focusLost(FocusEvent e) {
    }
	//和外部函数相连接
		public String getString()
		{
			return(s);
		}
		public int getX()
		{
			return(x);
		}
		public  int getY()
		{
            return(y);
		}
}
