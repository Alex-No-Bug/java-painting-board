package paintBoard;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class drawPolygon extends JFrame implements  FocusListener {
    private JLabel jl;
    private JTextField jtf;
    private JButton jb,CLEAR;
    private JPanel jp2;
    private MyPanel mp;
    
    public drawPolygon() 
    {  	
        jl = new JLabel("Enter the number of edges of the positive polygon:");
        jtf = new JTextField(6);
        jtf.addFocusListener(this);
        jb = new JButton("Confirm");
        jb.setBackground(Color.GRAY);
        jb.addActionListener(new ActionListener()
        		{
        	   @Override
        	    public void actionPerformed(ActionEvent e) {
        	        if (e.getSource() == jb) {
        	            String bianshu = jtf.getText();
        	            mp.bianshu = Integer.parseInt(bianshu);
        	            mp.repaint();
        	        }     
        	    }
        		});       
        mp = new MyPanel();
        jp2 = new JPanel();
        jp2.add(jl);
        jp2.add(jtf);
        jp2.add(jb);
        jp2.add(CLEAR);//����
        this.add(mp);
        this.add(jp2, BorderLayout.NORTH);
        this.setSize(500, 500);
        this.setVisible(true);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    @Override
    public void focusGained(FocusEvent e) {
        if (e.getSource() == jtf) {
            jtf.setText("");
        }
    }

    public void focusLost(FocusEvent e) {
    }
}

class MyPanel extends JPanel {
    int bianshu;
    private int bianshuMax = 20;
    private int[] x = new int[bianshuMax];
    private int[] y = new int[bianshuMax];
    MyPolygon mplg = new MyPolygon(x, y);  //������������

    public void paint(Graphics g) {
        g.clearRect(0, 0, this.getWidth(), this.getHeight()); //��Ϊrepaint������update�������Լ�������
        if (bianshu <= bianshuMax) {
            mplg.posOfPoint(bianshu);
            g.drawPolygon(x, y, bianshu);
        } 
        
        else {
            bianshuMax += 20;//  һ��Խ����ټ�20
            x = new int[bianshuMax];
            y = new int[bianshuMax];
            mplg = new MyPolygon(x, y);
            paint(g);
        }
    }
}
//��������εĶ�������
class MyPolygon {
	
    private int[] x;
    private int[] y;
    private int startX;// �����X����
    private int startY;// �����Y����
    private int r;// ���Բ�İ뾶

    public MyPolygon(int[] x, int[] y) {
        this.x = x;
        this.y = y;
        startX = 200;
        startY = 10;
        r = 200;
    }

    public void posOfPoint(int bianshu) {
        x[0] = startX;
        y[0] = startY;
        Point p = new Point();
        for (int i = 1; i < bianshu; i++) {
            p = nextPoint(((2 * Math.PI) / bianshu) * i);
            x[i] = p.x;
            y[i] = p.y;
        }
    }

    public Point nextPoint(double arc) {// arcΪ���ȣ��ڶ��㴦����ֱ������ϵ����r��arcȷ����һ���������
        Point p = new Point();
        p.x = (int) (x[0] - r * Math.sin(arc));
        p.y = (int) (y[0] + r - r * Math.cos(arc));
        return p;
    }
}//�����ĵ����ʹ��㷨