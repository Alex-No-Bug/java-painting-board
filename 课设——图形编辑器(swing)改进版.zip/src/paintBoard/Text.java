package paintBoard;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.io.Serializable;
public class Text extends Shape implements Serializable{  
	String TEXT;
	 public Text(int x1,int y1,int x2,int y2,Color color,int width,String name,String TEXT)
	 { 
	    	super(x1,y1,x2,y2,color,width,name);
	    	this.TEXT=TEXT;
	    	System.out.println("����TEXT");
	 } 
   //��д�����Draw������ʵ�־��εĻ���  
   public void Draw(Graphics2D g)
   {  
       g.setColor(this.color);  
       g.setStroke(new BasicStroke(width));
       System.out.println("����String"+TEXT);
       g.drawString(TEXT, x1, y1);
   }  
}  