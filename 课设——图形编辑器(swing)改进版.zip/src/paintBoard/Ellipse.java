package paintBoard;


import java.awt.BasicStroke;  
import java.awt.Color;  
import java.awt.Graphics2D;  
import java.io.Serializable;  
public class Ellipse extends Shape implements Serializable{  
	   public Ellipse(int x1,int y1,int x2,int y2,Color color,int width,String name){ 
	    	super(x1,y1,x2,y2,color,width,name);
	    }     
    public void Draw(Graphics2D g) {  
        g.setColor(this.color);  
        g.setStroke(new BasicStroke(width));  
        g.drawOval(x1, y1, x2-x1, y2-y1);  
    }        
}  
